

const errores =(error,res)=>{
    console.log('error :>> ', error);
    res.writeHead(500);
    res.end("Oops!! ha sucedido un error");    
};

module.exports = { 
    
    errores
};


