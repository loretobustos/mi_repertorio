const { Pool } = require("pg");
require('dotenv').config();

const config = {
    user: process.env.PG_USER,
    host: process.env.PG_HOST,
    database: process.env.PG_DATABASE,
    password: process.env.PG_PASSWORD,
    port: process.env.PG_PORT,
    max: process.env.PG_POOL_MAX,
    idleTimeoutMillis: process.env.PG_POOL_IDLE_TIMEOUT_MILLIS,
    connectionTimeoutMillis: process.env.PG_POOL_CONNECTION_TIMEOUT_MILLIS,
};



const pool = new Pool(config);

const insertar = async (datos) => {
    const consulta = {
        text: "INSERT INTO cancion (cancion, artista, tono) VALUES ($1, $2, $3)",
        values: datos,
    };
    try {
        const result = await pool.query(consulta);
        return result;
    } catch (error) {
        console.log(error.code);
        throw error;
    }
};

const consultar = async () => {
   
    try {
        const result = await pool.query("SELECT id, cancion, artista, tono FROM cancion ORDER BY id asc");
        return result;
    } catch (error) {
      
        console.log(error.code);
        throw error;
    }
};

const editar = async (datos) => {
    
    const consulta = {
        text: `UPDATE cancion SET
    cancion = $2,
    artista = $3,
    tono = $4
    WHERE id = $1 RETURNING *` ,
        values: datos,
    };

   
    try {
        const result = await pool.query(consulta);
        console.log(result);
        return result;
    } catch (error) {
        console.log(error);
        throw error;
    }
};

const eliminar = async (id) => {
   
    const consulta = {
        text: 'DELETE FROM cancion WHERE id = $1',
        values: [id]
    }
    try {
        const result = await pool.query(consulta);
        return result;
    } catch (error) {
        console.log(error.code);
        throw error;
    }
}

module.exports = { 
    
    insertar,
    consultar,
    editar,
    eliminar
};