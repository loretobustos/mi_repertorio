const http = require("http");
const {insertar,consultar,editar,eliminar} = require("./consultas");
const fsPromises = require("fs/promises");
const url = require("url");
const { errores } = require("./errores");


const PORT = 3000;
http
.createServer(async (req, res) => {
    if (req.url == "/" && req.method === "GET") {
        res.writeHead(200, { "content-type": "text/html" });
        try {
            const html = await fsPromises.readFile("index.html", "utf8");
            res.end(html);
        } catch (error) {
            console.log('error :>> ', error);
            res.writeHead(500);
            res.end("Oops!! ha sucedido un error");
        }
    } else if (req.url == "/cancion" && req.method == "POST") {
        let body = "";
        req.on("data", (chunk) => {
            body += chunk;
        });
        req.on("end", async () => {
            try {
              
                const datos = Object.values(JSON.parse(body));
                 console.log('bodyObj :>> ', datos);
                try {
                    await insertar(datos);
                    res.writeHead(201);
                    res.end();
                } catch (error) {
                    console.log('error :>> ', error);
                    res.writeHead(500);
                    res.end("Oops!! ha sucedido un error");
                }
            } catch (error) {
                console.log('error :>> ', error);
                res.writeHead(500);
                res.end("Oops!! ha sucedido un error");
            }
        });
    }else if (req.url == "/canciones" && req.method === "GET") {
        
        try {
            res.writeHead(200, { "content-type": "application/json" });
            const registros = await consultar();
           
            res.end(JSON.stringify(registros.rows));
        } catch (error) {
           errores(error,res)
        }
    } else if (req.url == "/cancion" && req.method == "PUT") {
        let body = "";
        req.on("data", (chunk) => {
            body += chunk;
        });
        req.on("end", async () => {
            try {
                const datos = Object.values(JSON.parse(body));
                try {
                    res.writeHead(201, { "content-type": "application/json" });
                    const respuesta = await editar(datos);
                    res.end(JSON.stringify(respuesta));
                } catch (error) {
                    errores(error,res)
                }
            } catch (error) {
                errores(error,res)
            }
        });
    }else if (req.url.startsWith("/cancion") && req.method == "DELETE") {
        const { id } = url.parse(req.url, true).query;
        try {
            const respuesta = await eliminar(id);
            res.end(JSON.stringify(respuesta));
          
        } catch (error) {
            errores(error,res)
        }
    
    } else {
        res.writeHead(404);
        res.end("Recurso no encontrado");
    }
})

.listen(PORT, () => console.log(`Iniciando servidor en puerto ${PORT}`));